import java.util.Date;

public class User {
    private String username;//用户名
    private int account;//账号
    private int userpassword;//密码
    private Date Creation_data;//注册日期
    private int Group;//用户类型
    private int phone_number;//电话号码

}
