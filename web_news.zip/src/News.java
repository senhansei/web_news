import java.util.Date;

public class News {
    private int uniquekey;//新闻ID
    private String 	category;//新闻分类
    private String title;//标题
    private String author;//作者
    private Date Release_time;//发布时间
    private int reading;//阅读量
    private int Comments;//评论数
    private String content;//新闻内容
}
